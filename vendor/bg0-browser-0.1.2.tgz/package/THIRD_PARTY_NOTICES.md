# Third-party notices

## BiRefNet browser models

BG0 downloads one of two MIT-licensed ONNX exports. The weights are not bundled
in this repository or package; their original license applies when downloaded
and cached in the browser.

- Full BiRefNet: `naddy24/birefnet-512-webgpu`, revision
  `ca02a86c094927479e2be583abe87f8ea73fcfda`. This browser-compatible 512px
  Swin-L export derives from `onnx-community/BiRefNet_512x512-ONNX` and
  `ZhengPeng7/BiRefNet_512x512`; empty ScatterND operations were removed.
- Lite fallback: `studioludens/birefnet-lite-512`, revision
  `4a3c40c36c94093cc1e724d9ea428b8fa4b57dc7`, derived from
  `ZhengPeng7/BiRefNet_lite`.

Model cards, licenses, attribution, limitations, and citation:

- https://huggingface.co/naddy24/birefnet-512-webgpu
- https://huggingface.co/onnx-community/BiRefNet_512x512-ONNX
- https://huggingface.co/ZhengPeng7/BiRefNet_512x512
- https://huggingface.co/studioludens/birefnet-lite-512
- https://github.com/ZhengPeng7/BiRefNet

## heic-to 1.5.2

`@bg0/browser` ships a minimally modified `heic-to` 1.5.2 browser module as
`dist/vendor/heic-to.js`. The modification selects a collection's primary
image instead of relying on libheif's top-level image ordering. It is loaded at
runtime through its public ES module interface and can be replaced with a
compatible modified build without rebuilding `@bg0/browser`.

`heic-to` and its bundled libheif 1.22.2 and libde265 1.0.16 decoder components
are licensed under the GNU Lesser General Public License, version 3 or later.
The LGPL terms are shipped beside the module as
`dist/vendor/heic-to-LICENSE.txt`, together with the incorporated GNU GPLv3
terms at `dist/vendor/GPL-3.0.txt`.

The exact corresponding source archives are included under
`dist/vendor/source/`:

- `heic-to-1.5.2.tgz` (SHA-256 `a301b46a2e5a2a050c44d7c1655d63b4c17415312ebcfa82920e950baffc5a7f`)
- `libheif-1.22.2.tar.gz` (SHA-256 `af30a8b32dfbc1dc86a7f0f55a53107dad35010a65ebf1feb468082e402b11e0`)
- `libde265-1.0.16.tar.gz` (SHA-256 `ed12c931759c1575848832f70db5071a001ac813db4e4f568ee08aef6e234d4e`)

The same directory includes `heic-to-primary.patch`, `guarded-transform.ts`,
and `BUILD.md`, which document the source modification and reproduce the exact
production artifact from the pinned upstream distribution file.

## iOS optimized BiRefNet-lite and ONNX Runtime

The iOS candidate uses the official MIT BiRefNet-lite checkpoint and a modified
sequential GridSample export (credited in docs/ios-model.md), dynamically
quantized and serialized as ORT. Provenance and hashes are in
`dist/vendor/ios/manifest.json`. BiRefNet MIT terms, ONNX Runtime MIT terms,
and the runtime third-party notices are distributed beside those files.
